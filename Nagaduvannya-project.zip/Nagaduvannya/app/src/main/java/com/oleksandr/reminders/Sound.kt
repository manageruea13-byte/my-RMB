package com.oleksandr.reminders

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.PowerManager

object Sound {
    /** Відтворює обрану мелодію; якщо не вдалося — стандартний сигнал будильника. */
    fun create(ctx: Context, uriString: String?, loop: Boolean): MediaPlayer? {
        val custom = uriString?.let { Uri.parse(it) }
        val fallback: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        return open(ctx, custom, loop) ?: open(ctx, fallback, loop)
    }

    private fun open(ctx: Context, uri: Uri?, loop: Boolean): MediaPlayer? {
        if (uri == null) return null
        val mp = MediaPlayer()
        return try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setWakeMode(ctx.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(ctx.applicationContext, uri)
            mp.isLooping = loop
            mp.prepare()
            mp.start()
            mp
        } catch (e: Exception) {
            try { mp.release() } catch (_: Exception) {}
            null
        }
    }
}
