package com.oleksandr.reminders

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var listView: ListView
    private var items: List<Reminder> = emptyList()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@MainActivity
            val r = items[position]

            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                alpha = if (r.enabled) 1f else 0.45f
            }
            col.addView(TextView(ctx).apply {
                text = r.timeText()
                textSize = 30f
                setTypeface(typeface, Typeface.BOLD)
            })
            if (r.comment.isNotBlank()) {
                col.addView(TextView(ctx).apply {
                    text = r.comment
                    textSize = 16f
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                })
            }
            col.addView(TextView(ctx).apply {
                text = r.describe() + "\n♪ " + r.ringtoneName
                textSize = 13f
                setTextColor(Color.GRAY)
            })

            val sw = Switch(ctx)
            sw.isChecked = r.enabled
            sw.setOnCheckedChangeListener { btn, checked ->
                if (checked && r.nextTrigger() == null) {
                    Toast.makeText(ctx, "Цей час уже минув — змініть дату в нагадуванні", Toast.LENGTH_LONG).show()
                    btn.isChecked = false
                } else {
                    r.enabled = checked
                    Store.upsert(ctx, r)
                    Scheduler.schedule(ctx, r)
                    if (checked) Toast.makeText(ctx, "Спрацює: " + r.nextText(), Toast.LENGTH_SHORT).show()
                    col.alpha = if (checked) 1f else 0.45f
                }
            }

            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(sw)
            return row
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Нагадування"

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val frame = FrameLayout(this)
        listView = ListView(this)
        val empty = TextView(this).apply {
            text = "Нагадувань ще немає.\nНатисніть «Додати нагадування»."
            gravity = Gravity.CENTER
            textSize = 16f
            setTextColor(Color.GRAY)
        }
        frame.addView(listView, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        listView.emptyView = empty
        listView.adapter = adapter

        val add = Button(this).apply {
            text = "＋ Додати нагадування"
            setOnClickListener { startActivity(Intent(this@MainActivity, EditActivity::class.java)) }
        }
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(add, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(12), dp(8), dp(12), dp(12))
        })
        setContentView(root)

        listView.setOnItemClickListener { _, _, pos, _ ->
            startActivity(Intent(this, EditActivity::class.java).putExtra("id", items[pos].id))
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            confirmDelete(items[pos])
            true
        }
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        items = Store.load(this).sortedBy {
            if (it.enabled) (it.nextMillis() ?: Long.MAX_VALUE) else Long.MAX_VALUE
        }
        adapter.notifyDataSetChanged()
    }

    private fun confirmDelete(r: Reminder) {
        AlertDialog.Builder(this)
            .setMessage("Видалити нагадування " + r.timeText() + "?")
            .setPositiveButton("Видалити") { _, _ ->
                Scheduler.cancel(this, r.id)
                Store.delete(this, r.id)
                refresh()
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!prefs.getBoolean("battery_tip_shown", false)) {
            prefs.edit().putBoolean("battery_tip_shown", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Надійні сповіщення")
                .setMessage(
                    "Щоб нагадування спрацьовували вчасно, вимкніть оптимізацію батареї для цього застосунку " +
                        "(знайдіть «Нагадування» у списку й виберіть «Не оптимізувати»). " +
                        "Також перевірте гучність будильника."
                )
                .setPositiveButton("Відкрити налаштування") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (_: Exception) {}
                }
                .setNegativeButton("Пізніше", null)
                .show()
        }
    }
}
