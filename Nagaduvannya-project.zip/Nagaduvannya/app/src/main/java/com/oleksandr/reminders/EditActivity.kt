package com.oleksandr.reminders

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import java.time.LocalDate

class EditActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val REQ_RINGTONE = 1
    private val REQ_FILE = 2

    private lateinit var r: Reminder
    private var curType = RepeatType.ONCE

    private lateinit var commentEt: EditText
    private lateinit var timeBtn: Button
    private lateinit var dateBox: LinearLayout
    private lateinit var dateLabel: TextView
    private lateinit var dateBtn: Button
    private lateinit var daysRow: LinearLayout
    private lateinit var melodyTv: TextView
    private val dayToggles = mutableListOf<ToggleButton>()

    private var preview: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", -1L)
        val existing = if (id != -1L) Store.get(this, id) else null
        r = existing ?: Reminder(id = System.currentTimeMillis())
        curType = r.type
        title = if (existing == null) "Нове нагадування" else "Редагування"

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(16), 0, dp(4))
        }

        // Коментар
        col.addView(label("Коментар"))
        commentEt = EditText(this).apply {
            hint = "Що нагадати"
            setText(r.comment)
            minLines = 2
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        col.addView(commentEt, LinearLayout.LayoutParams(MATCH, WRAP))

        // Час
        col.addView(label("Час"))
        timeBtn = Button(this).apply {
            textSize = 22f
            setOnClickListener {
                TimePickerDialog(this@EditActivity, { _, h, m ->
                    r.hour = h
                    r.minute = m
                    refreshUi()
                }, r.hour, r.minute, true).show()
            }
        }
        col.addView(timeBtn, LinearLayout.LayoutParams(MATCH, WRAP))

        // Повторення
        col.addView(label("Повторення"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, RepeatType.labels)
        spinner.setSelection(r.type)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                curType = pos
                refreshUi()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(spinner, LinearLayout.LayoutParams(MATCH, WRAP))

        // Дата
        dateBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dateLabel = label("Дата")
        dateBtn = Button(this).apply {
            setOnClickListener {
                DatePickerDialog(this@EditActivity, { _, y, m, d ->
                    r.startDate = LocalDate.of(y, m + 1, d)
                    refreshUi()
                }, r.startDate.year, r.startDate.monthValue - 1, r.startDate.dayOfMonth).show()
            }
        }
        dateBox.addView(dateLabel)
        dateBox.addView(dateBtn, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(dateBox, LinearLayout.LayoutParams(MATCH, WRAP))

        // Дні тижня
        daysRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        daysRow.addView(label("Дні тижня"))
        val toggles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0..6) {
            val tb = ToggleButton(this).apply {
                textOn = DAY_NAMES[i]
                textOff = DAY_NAMES[i]
                textSize = 13f
                minWidth = 0
                minimumWidth = 0
                setPadding(0, 0, 0, 0)
                isChecked = (r.daysMask and (1 shl i)) != 0
            }
            dayToggles.add(tb)
            toggles.addView(tb, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        daysRow.addView(toggles, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(daysRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // Мелодія
        col.addView(label("Мелодія"))
        melodyTv = TextView(this).apply {
            textSize = 16f
            text = "♪ " + r.ringtoneName
        }
        col.addView(melodyTv)
        val melodyRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        melodyRow.addView(Button(this).apply {
            text = "Обрати мелодію"
            setOnClickListener { chooseMelody() }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        melodyRow.addView(Button(this).apply {
            text = "▶ Прослухати"
            setOnClickListener { togglePreview() }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(melodyRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // Кнопки
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(24), 0, 0)
        }
        actions.addView(Button(this).apply {
            text = "Скасувати"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        actions.addView(Button(this).apply {
            text = "Зберегти"
            setOnClickListener { save() }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(ScrollView(this).apply { addView(col) })
        refreshUi()
    }

    private fun refreshUi() {
        timeBtn.text = r.timeText()
        dateBtn.text = r.startDate.format(DATE_FMT) + " (" + DAY_NAMES[r.startDate.dayOfWeek.value - 1] + ")"
        val needsDate = curType == RepeatType.ONCE || curType >= RepeatType.EVERY_2W
        dateBox.visibility = if (needsDate) View.VISIBLE else View.GONE
        daysRow.visibility = if (curType == RepeatType.WEEKDAYS) View.VISIBLE else View.GONE
        dateLabel.text = when (curType) {
            RepeatType.ONCE -> "Дата"
            RepeatType.MONTHLY -> "Починаючи з дати (далі — щомісяця цього числа)"
            else -> "Починаючи з дати (далі — у цей день тижня)"
        }
    }

    private fun chooseMelody() {
        val options = arrayOf(
            "Мелодії телефону",
            "Файл із пам'яті телефону (mp3 тощо)",
            "Стандартний сигнал будильника"
        )
        AlertDialog.Builder(this)
            .setTitle("Мелодія")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Оберіть мелодію")
                            r.ringtoneUri?.let {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it))
                            }
                        }
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_RINGTONE)
                    }
                    1 -> {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "audio/*"
                            addFlags(
                                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                            )
                        }
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_FILE)
                    }
                    2 -> {
                        r.ringtoneUri = null
                        r.ringtoneName = "Стандартний будильник"
                        melodyTv.text = "♪ " + r.ringtoneName
                    }
                }
            }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_RINGTONE -> {
                val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
                } else {
                    data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                }
                if (uri != null) {
                    r.ringtoneUri = uri.toString()
                    r.ringtoneName = try {
                        RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: "Мелодія"
                    } catch (e: Exception) {
                        "Мелодія"
                    }
                }
            }
            REQ_FILE -> {
                val uri = data.data
                if (uri != null) {
                    try {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) {}
                    r.ringtoneUri = uri.toString()
                    r.ringtoneName = queryName(uri)
                }
            }
        }
        melodyTv.text = "♪ " + r.ringtoneName
    }

    private fun queryName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: "Власний файл"
        } catch (e: Exception) {
            "Власний файл"
        }
    }

    private fun stopPreview() {
        handler.removeCallbacksAndMessages(null)
        try { preview?.stop() } catch (_: Exception) {}
        try { preview?.release() } catch (_: Exception) {}
        preview = null
    }

    private fun togglePreview() {
        if (preview != null) {
            stopPreview()
            return
        }
        preview = Sound.create(this, r.ringtoneUri, false)
        if (preview == null) {
            Toast.makeText(this, "Не вдалося відтворити мелодію", Toast.LENGTH_SHORT).show()
            return
        }
        preview?.setOnCompletionListener { stopPreview() }
        handler.postDelayed({ stopPreview() }, 10_000)
    }

    private fun save() {
        r.comment = commentEt.text.toString().trim()
        r.type = curType
        var mask = 0
        dayToggles.forEachIndexed { i, tb -> if (tb.isChecked) mask = mask or (1 shl i) }
        if (r.type == RepeatType.WEEKDAYS && mask == 0) {
            Toast.makeText(this, "Оберіть хоча б один день тижня", Toast.LENGTH_LONG).show()
            return
        }
        r.daysMask = mask
        r.enabled = true
        if (r.nextTrigger() == null) {
            Toast.makeText(this, "Цей час уже минув — оберіть пізнішу дату", Toast.LENGTH_LONG).show()
            return
        }
        Store.upsert(this, r)
        Scheduler.schedule(this, r)
        Toast.makeText(this, "Спрацює: " + r.nextText(), Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onPause() {
        super.onPause()
        stopPreview()
    }
}
