package com.oleksandr.reminders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmService : Service() {
    companion object {
        const val ACTION_STOP = "com.oleksandr.reminders.STOP"
        const val ACTION_SNOOZE = "com.oleksandr.reminders.SNOOZE"
        private const val CH_ALARM = "alarm"
        private const val CH_MISSED = "missed"
        private const val NOTIF_ID = 1001
        private const val RING_SECONDS = 60L
    }

    private var player: MediaPlayer? = null
    private var current: Reminder? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getLongExtra("id", -1L) ?: -1L

        when (intent?.action) {
            ACTION_STOP -> {
                handler.removeCallbacksAndMessages(null)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                Scheduler.snooze(this, id)
                handler.removeCallbacksAndMessages(null)
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val r = Store.get(this, id)
        if (r == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        current = r
        createChannels()
        val notif = buildNotification(r)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        stopSound()
        player = Sound.create(this, r.ringtoneUri, true)
        startVibration()

        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            current?.let { notifyMissed(it) }
            stopSelf()
        }, RING_SECONDS * 1000)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopSound()
        super.onDestroy()
    }

    private fun stopSound() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        @Suppress("DEPRECATION")
        (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel()
    }

    private fun startVibration() {
        @Suppress("DEPRECATION")
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 500), 0))
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        val alarm = NotificationChannel(CH_ALARM, "Сигнал нагадування", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val missed = NotificationChannel(CH_MISSED, "Пропущені нагадування", NotificationManager.IMPORTANCE_DEFAULT)
        nm.createNotificationChannel(alarm)
        nm.createNotificationChannel(missed)
    }

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun buildNotification(r: Reminder): Notification {
        val ringPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, RingActivity::class.java).putExtra("id", r.id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flags()
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags()
        )
        val snoozePi = PendingIntent.getService(
            this, 2,
            Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE).putExtra("id", r.id),
            flags()
        )
        val text = if (r.comment.isBlank()) "Нагадування" else r.comment
        @Suppress("DEPRECATION")
        return Notification.Builder(this, CH_ALARM)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("⏰ " + r.timeText())
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(ringPi)
            .setFullScreenIntent(ringPi, true)
            .addAction(R.drawable.ic_stat, "Зупинити", stopPi)
            .addAction(R.drawable.ic_stat, "Відкласти 10 хв", snoozePi)
            .build()
    }

    private fun notifyMissed(r: Reminder) {
        val pi = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), flags())
        val text = if (r.comment.isBlank()) "Нагадування" else r.comment
        val n = Notification.Builder(this, CH_MISSED)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Пропущене нагадування " + r.timeText())
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify(2000 + (r.id % 100000).toInt(), n)
    }
}
