package com.oleksandr.reminders

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class RingActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    private fun build() {
        val id = intent.getLongExtra("id", -1L)
        val r = Store.get(this, id)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
        }
        col.addView(TextView(this).apply { text = "⏰"; textSize = 64f; gravity = Gravity.CENTER })
        col.addView(TextView(this).apply {
            text = r?.timeText() ?: ""
            textSize = 48f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = if (r == null || r.comment.isBlank()) "Нагадування" else r.comment
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(32))
        })

        val stop = Button(this).apply {
            text = "Зупинити"
            textSize = 20f
            setOnClickListener {
                startService(Intent(this@RingActivity, AlarmService::class.java).setAction(AlarmService.ACTION_STOP))
                finish()
            }
        }
        val snooze = Button(this).apply {
            text = "Відкласти на 10 хв"
            setOnClickListener {
                startService(
                    Intent(this@RingActivity, AlarmService::class.java)
                        .setAction(AlarmService.ACTION_SNOOZE).putExtra("id", id)
                )
                finish()
            }
        }
        col.addView(stop, LinearLayout.LayoutParams(match, dp(72)))
        col.addView(snooze, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })
        setContentView(col)
    }
}
