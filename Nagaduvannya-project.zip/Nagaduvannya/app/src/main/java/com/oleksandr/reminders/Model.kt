package com.oleksandr.reminders

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

object RepeatType {
    const val ONCE = 0
    const val DAILY = 1
    const val WEEKDAYS = 2
    const val EVERY_2W = 3
    const val EVERY_3W = 4
    const val EVERY_4W = 5
    const val MONTHLY = 6

    val labels = listOf(
        "Один раз (на дату)",
        "Щодня",
        "По днях тижня",
        "Раз на 2 тижні",
        "Раз на 3 тижні",
        "Раз на 4 тижні",
        "Раз на місяць"
    )
}

val DAY_NAMES = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy")
val DATETIME_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")

data class Reminder(
    val id: Long,
    var comment: String = "",
    var hour: Int = 9,
    var minute: Int = 0,
    var type: Int = RepeatType.ONCE,
    var startDate: LocalDate = LocalDate.now(),
    var daysMask: Int = 0, // bit0 = Пн ... bit6 = Нд
    var ringtoneUri: String? = null,
    var ringtoneName: String = "Стандартний будильник",
    var enabled: Boolean = true
) {
    fun timeText(): String = "%02d:%02d".format(hour, minute)

    fun nextTrigger(now: LocalDateTime = LocalDateTime.now()): LocalDateTime? {
        val time = LocalTime.of(hour, minute)
        val today = now.toLocalDate()

        if (type == RepeatType.ONCE) {
            val dt = LocalDateTime.of(startDate, time)
            return if (dt.isAfter(now)) dt else null
        }
        if (type == RepeatType.DAILY) {
            val dt = LocalDateTime.of(today, time)
            return if (dt.isAfter(now)) dt else dt.plusDays(1)
        }
        if (type == RepeatType.WEEKDAYS) {
            if (daysMask == 0) return null
            for (i in 0..7) {
                val d = today.plusDays(i.toLong())
                val bit = 1 shl (d.dayOfWeek.value - 1)
                if ((daysMask and bit) != 0) {
                    val dt = LocalDateTime.of(d, time)
                    if (dt.isAfter(now)) return dt
                }
            }
            return null
        }
        if (type == RepeatType.EVERY_2W || type == RepeatType.EVERY_3W || type == RepeatType.EVERY_4W) {
            val period = 7L * (type - 1) // 3->2, 4->3, 5->4 тижні
            val first = LocalDateTime.of(startDate, time)
            if (first.isAfter(now)) return first
            val days = ChronoUnit.DAYS.between(startDate, today)
            val d = startDate.plusDays((days / period) * period)
            var dt = LocalDateTime.of(d, time)
            if (!dt.isAfter(now)) dt = dt.plusDays(period)
            return dt
        }
        if (type == RepeatType.MONTHLY) {
            val dom = startDate.dayOfMonth
            val first = LocalDateTime.of(startDate, time)
            val base = if (startDate.isAfter(today)) YearMonth.from(startDate) else YearMonth.from(today)
            for (i in 0..24) {
                val ym = base.plusMonths(i.toLong())
                val day = minOf(dom, ym.lengthOfMonth())
                val dt = LocalDateTime.of(ym.year, ym.month, day, hour, minute)
                if (dt.isAfter(now) && !dt.isBefore(first)) return dt
            }
            return null
        }
        return null
    }

    fun nextMillis(): Long? =
        nextTrigger()?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()

    fun nextText(): String = nextTrigger()?.format(DATETIME_FMT) ?: "—"

    fun describe(): String = when (type) {
        RepeatType.ONCE -> "Один раз: " + startDate.format(DATE_FMT)
        RepeatType.DAILY -> "Щодня"
        RepeatType.WEEKDAYS -> (0..6)
            .filter { (daysMask and (1 shl it)) != 0 }
            .joinToString(", ") { DAY_NAMES[it] }
        RepeatType.EVERY_2W, RepeatType.EVERY_3W, RepeatType.EVERY_4W ->
            "Раз на ${type - 1} тижні, " + DAY_NAMES[startDate.dayOfWeek.value - 1] +
                " (з " + startDate.format(DATE_FMT) + ")"
        RepeatType.MONTHLY -> "Раз на місяць, ${startDate.dayOfMonth}-го числа"
        else -> ""
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("comment", comment)
        put("hour", hour)
        put("minute", minute)
        put("type", type)
        put("startDate", startDate.toString())
        put("daysMask", daysMask)
        put("ringtoneUri", ringtoneUri ?: JSONObject.NULL)
        put("ringtoneName", ringtoneName)
        put("enabled", enabled)
    }

    companion object {
        fun fromJson(o: JSONObject) = Reminder(
            id = o.getLong("id"),
            comment = o.optString("comment", ""),
            hour = o.optInt("hour", 9),
            minute = o.optInt("minute", 0),
            type = o.optInt("type", RepeatType.ONCE),
            startDate = LocalDate.parse(o.optString("startDate", LocalDate.now().toString())),
            daysMask = o.optInt("daysMask", 0),
            ringtoneUri = if (o.isNull("ringtoneUri")) null else o.optString("ringtoneUri"),
            ringtoneName = o.optString("ringtoneName", "Стандартний будильник"),
            enabled = o.optBoolean("enabled", true)
        )
    }
}

object Store {
    private const val PREFS = "reminders"
    private const val KEY = "list"

    fun load(ctx: Context): MutableList<Reminder> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val out = mutableListOf<Reminder>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(Reminder.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            // пошкоджені дані ігноруємо
        }
        return out
    }

    private fun save(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun get(ctx: Context, id: Long): Reminder? = load(ctx).firstOrNull { it.id == id }

    fun upsert(ctx: Context, r: Reminder) {
        val list = load(ctx)
        val idx = list.indexOfFirst { it.id == r.id }
        if (idx >= 0) list[idx] = r else list.add(r)
        save(ctx, list)
    }

    fun delete(ctx: Context, id: Long) {
        save(ctx, load(ctx).filter { it.id != id })
    }
}
