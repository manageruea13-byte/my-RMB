package com.oleksandr.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val snooze = intent.getBooleanExtra("snooze", false)
        val r = Store.get(ctx, id) ?: return

        if (!snooze) {
            if (r.type == RepeatType.ONCE) {
                r.enabled = false
                Store.upsert(ctx, r)
            } else {
                Scheduler.schedule(ctx, r) // наступне повторення
            }
        }
        ctx.startForegroundService(Intent(ctx, AlarmService::class.java).putExtra("id", id))
    }
}
