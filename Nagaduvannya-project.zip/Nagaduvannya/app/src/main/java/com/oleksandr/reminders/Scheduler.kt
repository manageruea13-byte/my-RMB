package com.oleksandr.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri

object Scheduler {
    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun alarmPi(ctx: Context, id: Long, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            data = Uri.parse("reminder://" + (if (snooze) "snooze" else "main") + "/" + id)
            putExtra("id", id)
            putExtra("snooze", snooze)
        }
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(ctx: Context, r: Reminder) {
        cancel(ctx, r.id)
        if (!r.enabled) return
        val at = r.nextMillis() ?: return
        am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(at, showPi(ctx)), alarmPi(ctx, r.id, false))
    }

    fun cancel(ctx: Context, id: Long) {
        am(ctx).cancel(alarmPi(ctx, id, false))
    }

    fun snooze(ctx: Context, id: Long, minutes: Int = 10) {
        val at = System.currentTimeMillis() + minutes * 60_000L
        am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(at, showPi(ctx)), alarmPi(ctx, id, true))
    }

    fun scheduleAll(ctx: Context) {
        Store.load(ctx).forEach { schedule(ctx, it) }
    }
}
